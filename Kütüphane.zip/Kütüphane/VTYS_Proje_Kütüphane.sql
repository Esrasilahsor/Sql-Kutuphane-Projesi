CREATE DATABASE KUTUPHANE

USE KUTUPHANE
GO

				-- TABLO OLU�TURMA


CREATE TABLE OGRENCI(
	NO INT IDENTITY(1,1) PRIMARY KEY,
	AD NVARCHAR(50) NOT NULL,
	ADRES NVARCHAR(50) NOT NULL,
);

CREATE TABLE OGRENCI_TELEFON(
    ID INT IDENTITY(1,1) PRIMARY KEY, 
    O_NO INT NOT NULL,
    TELEFON NVARCHAR(20) NOT NULL,
    FOREIGN KEY (O_NO) REFERENCES OGRENCI(NO)
);


CREATE TABLE YAYINEVI(
	AD NVARCHAR(50) PRIMARY KEY NOT NULL,
	ADRES NVARCHAR(50) NOT NULL,
);


CREATE TABLE YAYINEVI_TELEFON(
	ID INT IDENTITY(1,1) PRIMARY KEY, 
	Y_AD NVARCHAR(50) NOT NULL,
	TELEFON NVARCHAR(20) NOT NULL,
	FOREIGN KEY(Y_AD) REFERENCES YAYINEVI(AD)
);


CREATE TABLE YAZAR(
	ID INT IDENTITY(1,1) PRIMARY KEY,
	AD NVARCHAR(50)  NOT NULL,
	ADRES NVARCHAR(100) NOT NULL
);

CREATE TABLE KITAP(
	ISBN BIGINT PRIMARY KEY,
	BASLIK NVARCHAR(50) NOT NULL,
	Y_AD NVARCHAR(50) NOT NULL,
	FOREIGN KEY (Y_AD) REFERENCES YAYINEVI(AD),
	Y_ID INT NOT NULL,
	FOREIGN KEY (Y_ID) REFERENCES YAZAR(ID)
);


CREATE TABLE KITAP_OGRENCI(
	TARIH DATE PRIMARY KEY,
	K_ISBN BIGINT NOT NULL,
	O_NO INT NOT NULL,
	FOREIGN KEY (K_ISBN) REFERENCES KITAP(ISBN),
	FOREIGN KEY (O_NO) REFERENCES OGRENCI(NO)
);



				-- VER� EKLEME

INSERT INTO OGRENCI (AD, ADRES) VALUES
('Ahmet Y�lmaz', 'Ankara'),
('Ay�e Demir', '�stanbul'),
('Mehmet Kaya', '�zmir'),
('Elif �ahin', 'Bursa'),
('Canan Y�ld�z', 'Konya'),
('Kerem Aksoy', 'Adana'),
('Zeynep U�ar', 'Antalya'),
('Murat Karaca', 'Trabzon'),
('Deniz Aksu', 'Samsun'),
('Fatma Yal��n', 'Mersin'),
('Ece Altun', 'Ankara'),
('Selim �zt�rk', '�stanbul'),
('Nisa Ko�', 'Kayseri'),
('Bar�� G�ner', 'Kocaeli'),
('Sibel Y�lmaz', 'Eski�ehir'),
('Onur Arslan', 'Malatya'),
('Gamze Ayd�n', 'Sivas'),
('Hakan Kurt', 'Amasya'),
('Hilal Yurt', 'Gaziantep'),
('Berk �etin', 'Ordu'),
('Furkan Ar�', 'Ankara'),
('Derya �ak�r', '�stanbul'),
('R�za Turan', '�zmir'),
('Tuba Uslu', 'Adana'),
('Melike Soylu', 'Antalya'),
('Alper �im�ek', 'Mersin'),
('Sinem Kutlu', 'Konya'),
('G�ktu� Demir', '�stanbul'),
('Asl� Ertem', 'Ankara'),
('Yi�it Bulut', 'Eski�ehir'),
('Mine Avc�', 'K�tahya'),
('Okan Er', '�orum'),
('Tu��e Ar', 'Manisa'),
('Arda Yazar', 'Sakarya'),
('Eyl�l Kar', '�anakkale'),
('Bora Ersoy', 'Hatay'),
('Seda Badem', 'Rize'),
('Naz Kurt', 'Erzurum'),
('Tamer G�l', 'K�r�kkale'),
('I��l Ko�ak', 'Bolu');


INSERT INTO OGRENCI_TELEFON(O_NO, TELEFON) VALUES
(1, '0532 111 22 33'),
(1, '0212 444 55 66'),
(2, '0541 222 33 44'),
(3, '0507 555 66 77'),
(3, '0312 333 44 55'),
(4, '0535 888 77 66'),
(5, '0506 999 55 44'),
(6, '0544 444 33 22'),
(6, '0216 222 11 00'),
(7, '0507 888 22 11'),
(8, '0536 111 44 55'),
(9, '0542 555 77 66'),
(10, '0533 909 80 70'),
(10, '0312 221 19 99'),
(11, '0538 700 11 22'),
(12, '0505 440 55 33'),
(12, '0212 320 10 20'),
(13, '0534 900 33 44'),
(14, '0507 770 40 50'),
(14, '0316 555 22 11'),
(15, '0531 200 50 60'),
(16, '0544 620 33 00'),
(17, '0506 880 44 11'),
(17, '0312 330 22 77'),
(18, '0532 101 88 99'),
(19, '0541 600 70 80'),
(20, '0504 900 20 10'),
(21, '0535 123 45 67'),
(21, '0216 333 44 11'),
(22, '0542 333 88 22'),
(23, '0539 444 55 66'),
(24, '0507 666 77 88'),
(24, '0312 200 40 50'),
(25, '0531 550 33 11'),
(26, '0544 410 20 30'),
(26, '0316 300 90 10'),
(27, '0506 720 32 11'),
(28, '0533 870 66 55'),
(28, '0212 990 77 44'),
(29, '0545 110 23 34'),
(30, '0534 220 44 55'),
(31, '0538 330 55 66'),
(32, '0505 440 66 77'),
(33, '0536 880 11 22'),
(34, '0543 910 88 99'),
(34, '0312 870 66 11'),
(35, '0532 770 44 55'),
(36, '0537 660 11 22'),
(37, '0504 990 33 44'),
(38, '0542 220 55 66'),
(39, '0542 220 55 64'),
(40, '0542 220 55 69');



INSERT INTO YAYINEVI (AD, ADRES) VALUES
('Alfa Yay�nlar�', '�stanbul'),
('Beta Kitap', 'Ankara'),
('Kule Yay�nc�l�k', '�zmir'),
('Mavi Kalem', '�stanbul'),
('G�ne� Yay�nlar�', 'Bursa'),
('Mart� Kitap', 'Antalya'),
('Papatya Bas�m', 'Konya'),
('Anka Yay�nc�l�k', 'Kayseri'),
('Derya Kitap', 'Mersin'),
('Tuna Bas�m', 'Samsun'),
('Atlas Yay�nlar�', 'Trabzon'),
('Kum Saati', 'Gaziantep'),
('Mor Defter', 'Eski�ehir'),
('Modern Kitap', 'Kocaeli'),
('Ay����� Bas�m', 'Adana');


INSERT INTO YAYINEVI_TELEFON(Y_AD,TELEFON) VALUES
('Alfa Yay�nlar�', '0212 789 10 11'),
('Beta Kitap', '0312 222 33 44'),
('Beta Kitap', '0312 555 66 77'),
('Kule Yay�nc�l�k', '0542 999 00 11'),
('Mavi Kalem', '0212 400 55 99'),
('Mavi Kalem', '0212 400 66 88'),
('G�ne� Yay�nlar�', '0224 300 40 50'),
('Mart� Kitap', '0242 555 12 34'),
('Papatya Bas�m', '0332 700 44 55'),
('Anka Yay�nc�l�k', '0352 210 33 22'),
('Derya Kitap', '0324 400 22 11'),
('Derya Kitap', '0324 400 33 22'),
('Tuna Bas�m', '0362 880 55 66'),
('Atlas Yay�nlar�', '0462 770 44 33'),
('Kum Saati', '0342 550 66 11'),
('Mor Defter', '0222 330 55 44'),
('Modern Kitap', '0262 700 90 10'),
('Ay����� Bas�m', '0322 600 30 20'),
('Ay����� Bas�m', '0322 600 40 50'),
('G�ne� Yay�nlar�', '0224 300 40 51');




INSERT INTO YAZAR (AD, ADRES) VALUES
('Orhan Pamuk', '�stanbul'),
('Ya�ar Kemal', 'Adana'),
('Sabahattin Ali', 'Edirne'),
('Ahmet �mit', '�stanbul'),
('Elif �afak', 'Ankara'),
('Ay�e Kulin', '�stanbul'),
('Z�lf� Livaneli', 'Mu�la'),
('Halide Edip Ad�var', '�stanbul'),
('Re�at Nuri G�ntekin', '�stanbul'),
('Peyami Safa', '�stanbul'),
('O�uz Atay', 'Ankara'),
('Aziz Nesin', '�stanbul'),
('Cemal S�reya', 'Erzincan'),
('Attila �lhan', '�zmir'),
('Can Y�cel', 'Mu�la'),
('Refik Halit Karay', '�stanbul'),
('Halikarnas Bal�k��s�', 'Bodrum'),
('Tar�k Bu�ra', 'Konya'),
('Orhan Veli', '�stanbul'),
('Cahit Zarifo�lu', 'Ankara');



INSERT INTO KITAP(ISBN, BASLIK, Y_AD, Y_ID) VALUES
(9786050001001, 'Masumiyet M�zesi', 'Alfa Yay�nlar�', 1),
(9786050001002, 'K�rm�z� Sa�l� Kad�n','Tuna Bas�m', 1),
(9786050001003, 'Kar', 'Kule Yay�nc�l�k', 1),
(9786050001004, '�nce Memed','Beta Kitap', 2),
(9786050001005, 'Binbo�alar Efsanesi','Kule Yay�nc�l�k', 2),
(9786050001006, 'Kuyucakl� Yusuf', 'Kule Yay�nc�l�k', 3),
(9786050001007, '��imizdeki �eytan','Beta Kitap', 3),
(9786050001008, 'Baba ve Pi�','Derya Kitap', 5),
(9786050001009, 'Araf','G�ne� Yay�nlar�', 5),
(9786050001010, 'Karde�imin Hikayesi','Kum Saati', 4),
(9786050001011, 'Beyo�lu Rapsodisi','Atlas Yay�nlar�', 4),
(9786050001012, 'Sevdalinka','Ay����� Bas�m', 6),
(9786050001013, 'Ad�: Aylin','Papatya Bas�m', 6),
(9786050001014, 'Serenad','Anka Yay�nc�l�k', 7),
(9786050001015, 'Huzursuzluk', 'Kule Yay�nc�l�k', 7),
(9786050001016, 'Sinekli Bakkal','G�ne� Yay�nlar�', 8),
(9786050001017, 'Handan','Mavi Kalem', 8),
(9786050001018, '�al�ku�u','Derya Kitap', 9),
(9786050001019, 'Ye�il Gece', 'Alfa Yay�nlar�', 9),
(9786050001020, 'Fatih-Harbiye','Kum Saati', 10),
(9786050001021, 'Dokuzuncu Hariciye Ko�u�u', 'Kule Yay�nc�l�k', 10),
(9786050001022, 'Tutunamayanlar','Mavi Kalem', 11),
(9786050001023, 'Bir Bilim Adam�n�n Roman�','Ay����� Bas�m', 11),
(9786050001024, 'Z�b�k','Modern Kitap', 12),
(9786050001025, 'Ya�ar Ne Ya�ar Ne Ya�amaz','Mor Defter', 12),
(9786050001026, '�vercinka','Beta Kitap', 13),
(9786050001027, 'Sevda S�zleri','Kule Yay�nc�l�k', 13),
(9786050001028, 'Ben Sana Mecburum','Mor Defter', 14),
(9786050001029, 'Sisler Bulvar�','Atlas Yay�nlar�', 14),
(9786050001030, 'Canfeda','Anka Yay�nc�l�k', 15),
(9786050001031, 'G�le G�le Hat�ralar','Beta Kitap', 15),
(9786050001032, 'Memleket Hikayeleri','Modern Kitap', 16),
(9786050001033, 'Gurbet Hikayeleri','Derya Kitap', 16),
(9786050001034, 'Aganta Burina Burinata','Tuna Bas�m', 17),
(9786050001035, 'Mavi S�rg�n','Mavi Kalem', 17),
(9786050001036, 'K���k A�a', 'G�ne� Yay�nlar�', 18),
(9786050001037, 'Osmanc�k', 'Kule Yay�nc�l�k', 18),
(9786050001038, 'Garip','Mart� Kitap', 19),
(9786050001039, 'Destan Gibi','Modern Kitap', 19),
(9786050001040, 'Yedi G�zel Adam','Beta Kitap', 20),
(9786050001041, '�ns','Mart� Kitap', 20),

(9786050001042, 'Sessiz Ev','Alfa Yay�nlar�', 1),
(9786050001043, 'Benim Ad�m K�rm�z�', 'Papatya Bas�m', 1),
(9786050001044, 'Ortadirek','Mor Defter', 2),
(9786050001045, 'Yer Demir G�k Bak�r','Kule Yay�nc�l�k', 2),
(9786050001046, 'K�rk Mantolu Madonna','Derya Kitap', 3),
(9786050001047, 'S�r�a K��k','Anka Yay�nc�l�k', 12),
(9786050001048, 'Huzur','Tuna Bas�m', 9),
(9786050001049, 'A�k-� Memnu','Kule Yay�nc�l�k', 8),
(9786050001050, 'Beyo�lu''nun En G�zel Abisi','G�ne� Yay�nlar�', 4),
(9786050001051, 'Sadakat','Mart� Kitap', 5),
(9786050001052, 'Bir G�n Tek Ba��na','Beta Kitap', 14),
(9786050001053, 'Tehlikeli Oyunlar','Modern Kitap', 11),
(9786050001054, '�eker Portakal�','Mor Defter', 12),
(9786050001055, 'Aylak Adam', 'Beta Kitap', 10),
(9786050001056, 'Yeni Hayat', 'Kum Saati', 1),
(9786050001057, 'Haremde Ya�am','Mart� Kitap', 8),
(9786050001058, 'A�k','Tuna Bas�m', 5),
(9786050001059, 'Leyla ile Mecnun','Mavi Kalem', 7),
(9786050001060, '�stanbul Hat�ras�','Kum Saati', 4),
(9786050001061, 'Kaplan�n S�rt�nda','Kum Saati', 10),
(9786050001062, 'Mutluluk','Kule Yay�nc�l�k', 7),
(9786050001063, 'Son Ada', 'Anka Yay�nc�l�k', 7),
(9786050001064, 'Ate� Etme �stanbul','Papatya Bas�m', 14),
(9786050001065, 'Korkuyorum Anne','Ay����� Bas�m', 11),
(9786050001066, 'G�n Olur Asra Bedel','Alfa Yay�nlar�', 13),
(9786050001067, 'Sevgili Ars�z �l�m','Atlas Yay�nlar�', 6),
(9786050001068, 'S�per Baba','Kule Yay�nc�l�k', 12),
(9786050001069, 'S�r', 'Anka Yay�nc�l�k', 15),
(9786050001070, 'Gece Yar�s� K�t�phanesi','Mor Defter', 6),
(9786050001071, 'K�rk Yalan','Beta Kitap', 12),
(9786050001072, 'Satran�', 'Beta Kitap', 13),
(9786050001073, 'K�rlang�� ���l���','Mart� Kitap', 4),
(9786050001074, 'G�n�l Han�m','Mavi Kalem', 16),
(9786050001075, 'Eyl�l','G�ne� Yay�nlar�', 10),
(9786050001076, 'Aylak Adam', 'Mavi Kalem', 13),
(9786050001077, 'Uzun Hikaye','Mor Defter', 18),
(9786050001078, 'Sahnenin D���ndakiler','Alfa Yay�nlar�', 9),
(9786050001079, 'Kay�p S�z','Papatya Bas�m', 20),
(9786050001080, 'S��rama Tahtas�','Papatya Bas�m', 17);



INSERT INTO KITAP_OGRENCI(TARIH, K_ISBN, O_NO) VALUES
('2023-01-12', 9786050001001, 1),
('2023-01-15', 9786050001004, 2),
('2023-01-18', 9786050001006, 3),
('2023-01-22', 9786050001021, 28),
('2023-02-05', 9786050001002, 10),
('2023-02-08', 9786050001005, 33),
('2023-02-12', 9786050001007, 32),
('2023-02-20', 9786050001009, 5),
('2023-03-01', 9786050001010, 12),
('2023-03-11', 9786050001012, 15),
('2023-03-15', 9786050001014, 8),
('2023-03-20', 9786050001016, 17),
('2023-04-01', 9786050001018, 9),
('2023-04-10', 9786050001020, 22),
('2023-04-18', 9786050001022, 19),
('2023-04-25', 9786050001024, 14),
('2023-05-05', 9786050001026, 29),
('2023-05-15', 9786050001028, 23),
('2023-05-22', 9786050001030, 18),
('2023-05-30', 9786050001032, 37),
('2023-06-04', 9786050001034, 10),
('2023-06-10', 9786050001036, 24),
('2023-06-15', 9786050001038, 6),
('2023-06-20', 9786050001040, 39),
('2023-06-25', 9786050001041, 3),
('2023-07-01', 9786050001043, 27),
('2023-07-05', 9786050001045, 26),
('2023-07-10', 9786050001047, 12),
('2023-07-15', 9786050001049, 40),
('2023-07-20', 9786050001051, 6),
('2023-07-25', 9786050001053, 2),
('2023-08-01', 9786050001055, 30),
('2023-08-05', 9786050001057, 36),
('2023-08-10', 9786050001059, 4),
('2023-08-15', 9786050001061, 12),
('2023-08-20', 9786050001063, 18),
('2023-08-25', 9786050001065, 15),
('2023-08-30', 9786050001067, 11),
('2023-09-05', 9786050001069, 28),
('2023-09-10', 9786050001071, 40),
('2023-09-15', 9786050001073, 24),
('2023-09-20', 9786050001075, 35),
('2023-09-25', 9786050001077, 13),
('2023-09-30', 9786050001079, 37);


				-- SQL SORGULARI


-- Se�me

SELECT * FROM OGRENCI
SELECT * FROM OGRENCI_TELEFON

SELECT * FROM YAYINEVI
SELECT * FROM YAYINEVI_TELEFON

SELECT * FROM YAZAR
SELECT * FROM KITAP
SELECT * FROM KITAP_OGRENCI

SELECT ADRES FROM YAZAR

SELECT NO,AD FROM OGRENCI
SELECT ISBN, BASLIK FROM KITAP

SELECT BASLIK,Y_AD FROM KITAP WHERE ISBN=9786050001004

SELECT * FROM KITAP_OGRENCI WHERE TARIH>'2023-05-22' ORDER BY TARIH


-- G�ncelleme 
UPDATE OGRENCI_TELEFON SET TELEFON= '0532 111 22 33' WHERE O_NO=1
UPDATE YAYINEVI SET ADRES='Sivas' WHERE AD='Tuna Bas�m'
UPDATE KITAP_OGRENCI SET O_NO='13' WHERE K_ISBN='9786050001043'


-- Silme
DELETE FROM OGRENCI_TELEFON  WHERE TELEFON= '0532 111 22 33'
DELETE FROM KITAP_OGRENCI  WHERE O_NO= 2
-- Drop kullan�m� �rneklendirilmek i�in silinmi�tir. Geri eklenmesi daha sa�l�kl�d�r.
DROP TABLE KITAP_OGRENCI 

DROP DATABASE KUTUPHANE -- Veritaban�n� siler.